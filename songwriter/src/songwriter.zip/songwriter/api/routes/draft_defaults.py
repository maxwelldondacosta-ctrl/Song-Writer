"""Default 4-section arc used when a song has no sections and the user clicks 'Draft all'."""

DEFAULT_SECTIONS = [
    {"id": "v1", "label": "Verse 1", "cadence": "melodic-glide"},
    {"id": "ch1", "label": "Chorus", "cadence": "pop-hook"},
    {"id": "v2", "label": "Verse 2", "cadence": "melodic-glide"},
    {"id": "ch2", "label": "Chorus", "cadence": "pop-hook"},
]
