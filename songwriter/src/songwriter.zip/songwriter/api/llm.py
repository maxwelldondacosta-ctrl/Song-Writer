"""LLM provider routing for Songwriter.

Route:
  draft tier ("sonnet") → Cerebras Qwen3-235B  (~1-3s/call, ~$0.004)
  fast tier  ("haiku")  → Anthropic Haiku 4.5  (~3-5s/call, ~$0.003)
  fallback              → claude --print subprocess (slow, no API cost)

Key files: ~/.cerebras_api_key, ~/.maxrpg_api_key
"""

from __future__ import annotations

import json
import logging
import os
import re
import subprocess
import time
import urllib.error
import urllib.request
from typing import Any

from songwriter.api.settings import Settings, get_settings


log = logging.getLogger("songwriter.llm")
if not logging.getLogger().handlers:
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(name)s %(message)s")


class LLMError(RuntimeError):
    pass


_JSON_FENCE = re.compile(r"```(?:json)?\s*(\{.*?\}|\[.*?\])\s*```", re.DOTALL)


def _tag(prompt: str) -> str:
    first_line = prompt.lstrip().splitlines()[0] if prompt.strip() else ""
    return (first_line[:60] + "…") if len(first_line) > 60 else first_line or "(empty)"


# ── Cerebras ─────────────────────────────────────────────────────────────────

_CEREBRAS_URL = "https://api.cerebras.ai/v1/chat/completions"


def _cerebras_key(settings: Settings) -> str:
    path = os.path.expanduser(settings.cerebras_key_path)
    if os.path.exists(path):
        with open(path) as f:
            return f.read().strip()
    return os.environ.get("CEREBRAS_API_KEY", "")


def _ask_cerebras(prompt: str, settings: Settings) -> str:
    key = _cerebras_key(settings)
    if not key:
        raise LLMError("no Cerebras key (checked ~/.cerebras_api_key and CEREBRAS_API_KEY env)")

    payload = {
        "model": settings.cerebras_model_id,
        "max_tokens": 4096,
        "temperature": 0.85,
        "messages": [{"role": "user", "content": prompt}],
    }
    req = urllib.request.Request(
        _CEREBRAS_URL,
        data=json.dumps(payload).encode(),
        headers={
            "Content-Type": "application/json",
            "Authorization": f"Bearer {key}",
            "User-Agent": "songwriter/1.0",  # Cloudflare requires this
        },
        method="POST",
    )
    t0 = time.perf_counter()
    try:
        with urllib.request.urlopen(req, timeout=settings.llm_timeout_s) as resp:
            raw = json.loads(resp.read().decode())
    except urllib.error.HTTPError as e:
        try:
            err = json.loads(e.read().decode()).get("error") or {}
            msg = err.get("message", str(e)) if isinstance(err, dict) else str(err)
        except Exception:
            msg = str(e)
        raise LLMError(f"Cerebras HTTP {e.code}: {msg}")
    except Exception as e:
        raise LLMError(f"Cerebras request failed: {e}")

    elapsed = time.perf_counter() - t0
    text = (raw.get("choices") or [{}])[0].get("message", {}).get("content", "")
    log.info(f"[llm/cerebras] ok in {elapsed:.1f}s ({len(text)} chars out)")
    return text.strip()


# ── Anthropic API ─────────────────────────────────────────────────────────────

_ANTHROPIC_URL = "https://api.anthropic.com/v1/messages"


def _anthropic_key(settings: Settings) -> str:
    path = os.path.expanduser(settings.anthropic_key_path)
    if os.path.exists(path):
        with open(path) as f:
            return f.read().strip()
    return os.environ.get("ANTHROPIC_API_KEY", "") or os.environ.get("MAXRPG_API_KEY", "")


def _ask_anthropic(prompt: str, settings: Settings) -> str:
    key = _anthropic_key(settings)
    if not key:
        raise LLMError("no Anthropic key (checked ~/.maxrpg_api_key and ANTHROPIC_API_KEY env)")

    payload = {
        "model": settings.anthropic_haiku_id,
        "max_tokens": 2048,
        "messages": [{"role": "user", "content": prompt}],
    }
    req = urllib.request.Request(
        _ANTHROPIC_URL,
        data=json.dumps(payload).encode(),
        headers={
            "Content-Type": "application/json",
            "x-api-key": key,
            "anthropic-version": "2023-06-01",
        },
        method="POST",
    )
    t0 = time.perf_counter()
    try:
        with urllib.request.urlopen(req, timeout=settings.llm_timeout_s) as resp:
            raw = json.loads(resp.read().decode())
    except urllib.error.HTTPError as e:
        try:
            msg = json.loads(e.read().decode()).get("error", {}).get("message", str(e))
        except Exception:
            msg = str(e)
        raise LLMError(f"Anthropic HTTP {e.code}: {msg}")
    except Exception as e:
        raise LLMError(f"Anthropic request failed: {e}")

    elapsed = time.perf_counter() - t0
    text = ""
    for block in raw.get("content", []):
        if block.get("type") == "text":
            text = block["text"]
            break
    log.info(f"[llm/anthropic] ok in {elapsed:.1f}s ({len(text)} chars out)")
    return text.strip()


# ── claude --print fallback ───────────────────────────────────────────────────

def _ask_cli(prompt: str, model: str | None, settings: Settings) -> str:
    cmd = [settings.claude_cli]
    if model:
        cmd += ["--model", model]
    cmd += ["--print", prompt]
    t0 = time.perf_counter()
    log.info(f"[llm/cli] start ({model or 'default'}): {_tag(prompt)!r}")
    try:
        proc = subprocess.run(cmd, capture_output=True, text=True, timeout=settings.llm_timeout_s)
    except subprocess.TimeoutExpired:
        raise LLMError(f"claude --print timed out after {time.perf_counter() - t0:.1f}s")
    if proc.returncode != 0:
        raise LLMError(f"claude --print failed (exit {proc.returncode}): {proc.stderr.strip()}")
    log.info(f"[llm/cli] ok in {time.perf_counter() - t0:.1f}s")
    return proc.stdout.strip()


# ── public interface ──────────────────────────────────────────────────────────

def ask_claude(prompt: str, *, settings: Settings | None = None, model: str | None = None) -> str:
    settings = settings or get_settings()
    t0 = time.perf_counter()
    tag = _tag(prompt)
    log.info(f"[llm] start model={model!r}: {tag!r} (chars={len(prompt)})")

    if model == settings.draft_model:
        result = _ask_cerebras(prompt, settings)
    elif model == settings.fast_model:
        result = _ask_anthropic(prompt, settings)
    else:
        result = _ask_cli(prompt, model, settings)

    log.info(f"[llm] done in {time.perf_counter() - t0:.1f}s: {tag!r}")
    return result


def ask_claude_json(prompt: str, *, settings: Settings | None = None, model: str | None = None) -> Any:
    raw = ask_claude(prompt, settings=settings, model=model)
    m = _JSON_FENCE.search(raw)
    candidate = m.group(1) if m else raw
    try:
        return json.loads(candidate)
    except json.JSONDecodeError as e:
        raise LLMError(f"could not parse JSON from LLM output: {e}\noutput was:\n{raw}") from e
