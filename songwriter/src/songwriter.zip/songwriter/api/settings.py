from pathlib import Path

from pydantic_settings import BaseSettings, SettingsConfigDict

from songwriter.seeds import DB_PATH as DEFAULT_DB_PATH


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_prefix="SONGWRITER_", env_file=".env", extra="ignore")

    db_path: Path = DEFAULT_DB_PATH
    songs_dir: Path = Path.home() / "Songwriter" / "songs"
    cors_origins: list[str] = ["http://localhost:3737", "http://localhost:3000"]

    # Abstract tier labels used throughout call sites
    draft_model: str = "sonnet"   # initial lyric gen — routed to Cerebras Qwen3-235B
    fast_model: str = "haiku"     # corrections + validation — routed to Anthropic Haiku

    # Provider model IDs
    cerebras_model_id: str = "qwen-3-235b-a22b-instruct-2507"
    anthropic_haiku_id: str = "claude-haiku-4-5-20251001"

    # API key file paths
    cerebras_key_path: str = "~/.cerebras_api_key"
    anthropic_key_path: str = "~/.maxrpg_api_key"

    # Claude CLI fallback (used when provider keys are missing)
    claude_cli: str = "claude"
    llm_timeout_s: int = 60


def get_settings() -> Settings:
    return Settings()
