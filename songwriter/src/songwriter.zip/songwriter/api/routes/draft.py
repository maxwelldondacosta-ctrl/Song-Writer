"""POST /songs/{slug}/draft — iterative draft → validate → critique → redraft loop.

The loop is the whole point. Each attempt:
  1. Generate (or correct) lyrics via claude --print.
  2. Scrub any burn-list words (guarantees they never reach the JSON).
  3. Run full validation: 4 deterministic engines + LLM-judged Story/Sentence.
  4. Score the candidate. If passing OR max attempts hit, ship the best so far.
  5. Otherwise build a correction prompt that surfaces every fail/warn and repeats.

The deterministic engines are precisely what Claude can't accurately self-check
(syllable counts from CMUdict, ARPAbet stress patterns, rhyme classes), so the
loop is structurally meaningful — it's not just asking the same model to grade
its own homework.
"""

from __future__ import annotations

import json
import re
import sqlite3
from datetime import datetime, timezone
from typing import Annotated, Any

from fastapi import APIRouter, Depends, HTTPException, Query

from songwriter.api.deps import get_db, get_settings
from songwriter.api.llm import LLMError, ask_claude_json
from songwriter.api.schemas import Section, Song
from songwriter.api.settings import Settings
from songwriter.api.songs_io import path_for_slug, read_song, write_song
from songwriter.api.validation.orchestrator import validate_song
from songwriter.api.vocab_resolver import resolve_vocab
from songwriter.api.ws import manager as ws_manager


router = APIRouter()


MAX_ATTEMPTS = 1  # one shot by default. caller bumps via ?max_attempts=2..8 to opt into the iterative correction loop.


# ---------------- prompt building ----------------

_INITIAL_PROMPT = """\
Write lyrics for the listed sections. Output STRICT JSON only, no prose.

TOPIC (every line must directly serve this — no filler): {topic}
STORY ARC: event={event!r} → emotion={emotion!r} → resolution={resolution!r}
EMOTION ARC: {emotion_arc}
GENRE: {genre} / {sub_genre}
LENS: {lens_block}

ANCHOR WORDS (lean on these — concrete vocabulary tuned to {genre}/{emotion_arc}; source: {anchor_source}):
{anchor_words}

PRODUCTION TEXTURE (the sonic register the lyric should live inside): {pos_descriptors}
AVOID (anti-vibe — drift away from these): {neg_descriptors}

SECTIONS — each section has a distinct narrative role. Do NOT repeat the same idea across sections:
{section_block}

CADENCE TARGETS (syllable count per line is what matters most — stress patterns are secondary):
{cadence_compact}

RULES:
- STORY FIRST. Each section must advance or deepen the story. Rhyme is a tool, not the goal.
- Concrete imagery only — name the object, place, or action. No abstract emotion words.
- Verse 1 opens a scene. Verse 2 moves it forward. Don't rehash verse 1 in verse 2.
- Use 2-4 anchor words per section where they fit; never force them.
- Match each section's syllable target (±2 syllables per line).
- End-rhyme between successive lines — but sacrifice rhyme before sacrificing meaning.
- Forbidden words (do NOT use): {burn_words}
- No copyrighted lyric content. Original lines only.

Output JSON in a ```json fenced block:
{{"sections":[{{"id":"<id>","lyrics":["line","line",...]}}]}}
"""


_CORRECTION_PROMPT = """\
You are making SURGICAL FIXES to failing lyrics. DO NOT rewrite the song. DO NOT change lines that are passing.

Reproduce every passing line verbatim. Only touch the specific lines causing the failures listed below.

TOPIC (every surviving line must still serve this): {topic}
STORY: event={event!r} | emotion={emotion!r} | resolution={resolution!r}
LENS: {lens_block}

ANCHOR WORDS (swap in these where a replacement is needed):
{anchor_words}

CURRENT LYRICS — copy each line exactly unless it must change:
{prev_lyrics_block}

FAILURES TO FIX:
{feedback_block}

HOW TO FIX EACH FAILURE TYPE:
- singability FAIL → The line's syllable count is too far from the cadence target. Recount syllables using natural speech rhythm and rewrite only that line to land within ±2 of the target. Contractions count as one syllable each.
- phonetic_texture FAIL → Too many consecutive consonant clusters or vowel collisions. Break them up, prefer open vowels (ah, oh, ay), reduce plosive stacking.
- rhyme_cadence FAIL → The end-word of a line doesn't share a rhyme class with its pair. Swap only the final word for one from the same rhyme class. Keep everything else.
- story_sentence FAIL → A line is too abstract, vague, or uses a generic emotion word. Replace it with one concrete image or action grounded in: {topic}. Name the object/place/person explicitly.

CONSTRAINTS:
- Return ALL sections in the output JSON — even ones you did not touch.
- Forbidden words (do NOT use any of these): {burn_words}

Output JSON in a ```json fenced block:
{{"sections":[{{"id":"<id>","lyrics":["..."]}}]}}
"""


# ---------------- DB loaders ----------------

def _load_lens(db: sqlite3.Connection, slug: str | None) -> str:
    """Build a thick lens block. Includes:
    - display name + role
    - full adoption_prompt (the literal instructions the lens carries)
    - top 4 craft_signature bullets
    - vocab fingerprint: signature_words, semantic_anchors, avoided_words,
      vowel_priority_words
    - hook_style
    - phonetic preferences (vowel preference, attack profile, density)
    - preferred_cadences

    These all materially shape what 'in the X craft mode' means; trimming
    them silently was the cause of drafts not feeling like the picked lens.
    """
    if not slug:
        return "(no lens — write in the genre's default style)"
    row = db.execute(
        """
        SELECT display_name, role, adoption_prompt, craft_signature,
               vocab_fingerprint, phonetic_fingerprint, preferred_cadences,
               hook_style, writing_style
        FROM songwriter_profiles WHERE slug = ?
        """,
        (slug,),
    ).fetchone()
    if not row:
        return f"({slug!r} not found in profiles)"

    parts: list[str] = [f"{row['display_name']} ({row['role']})"]
    parts.append("")
    ap = (row["adoption_prompt"] or "").strip()
    if ap:
        parts.append("ADOPTION INSTRUCTIONS (treat as authoritative):")
        parts.append(ap)
        parts.append("")

    cs = json.loads(row["craft_signature"]) if row["craft_signature"] else []
    if cs:
        parts.append("CRAFT SIGNATURE (top mechanics):")
        for line in cs[:4]:
            parts.append(f"  - {line}")
        parts.append("")

    vf = json.loads(row["vocab_fingerprint"]) if row["vocab_fingerprint"] else {}
    if isinstance(vf, dict):
        sig = vf.get("signature_words") or []
        anchors = vf.get("semantic_anchors") or []
        avoided = vf.get("avoided_words") or []
        vowel_pri = vf.get("vowel_priority_words") or []
        if sig: parts.append(f"SIGNATURE WORDS (use freely): {', '.join(sig)}")
        if anchors: parts.append(f"SEMANTIC ANCHORS: {', '.join(anchors)}")
        if avoided: parts.append(f"AVOIDED (do NOT use): {', '.join(avoided)}")
        if vowel_pri: parts.append(f"VOWEL-PRIORITY WORDS (these belt well): {', '.join(vowel_pri)}")

    pf = json.loads(row["phonetic_fingerprint"]) if row["phonetic_fingerprint"] else {}
    if isinstance(pf, dict) and (pf.get("attack_profile") or pf.get("vowel_preference")):
        parts.append(
            f"PHONETIC PROFILE: vowel-preference={pf.get('vowel_preference', '?')}, "
            f"attack={pf.get('attack_profile', '?')}, "
            f"consonant-density={pf.get('consonant_density', '?')}"
        )

    pc = json.loads(row["preferred_cadences"]) if row["preferred_cadences"] else []
    if pc:
        parts.append(f"PREFERRED CADENCES: {', '.join(pc)}")

    if row["hook_style"]:
        parts.append(f"HOOK STYLE: {row['hook_style']}")

    return "\n".join(parts)


def _load_production(db: sqlite3.Connection, sub_genre_slug: str) -> tuple[list[str], list[str]]:
    row = db.execute(
        """
        SELECT pf.positive_descriptors, pf.negative_descriptors
        FROM production_fingerprints pf
        JOIN sub_genres sg ON sg.id = pf.sub_genre_id
        WHERE sg.slug = ?
        """,
        (sub_genre_slug,),
    ).fetchone()
    if not row:
        return [], []
    pos = json.loads(row["positive_descriptors"]) if row["positive_descriptors"] else []
    neg = json.loads(row["negative_descriptors"]) if row["negative_descriptors"] else []
    return pos, neg


def _load_burn_dict(db: sqlite3.Connection) -> dict[str, list[str]]:
    """Burn-list as {word: [alternatives]} for both prompt-time avoidance and post-draft scrub."""
    rows = db.execute(
        "SELECT word, alternatives FROM suno_burn_list WHERE severity IN ('strong', 'extreme')"
    ).fetchall()
    out: dict[str, list[str]] = {}
    for r in rows:
        try:
            out[r["word"]] = json.loads(r["alternatives"]) if r["alternatives"] else []
        except json.JSONDecodeError:
            out[r["word"]] = []
    return out


def _load_cadence_compact(db: sqlite3.Connection, sections: list[Section]) -> str:
    """Thicker cadence block. For each cadence used in the song, give:
       - syllable template
       - stress template (1=stressed, 0=unstressed, ?=wildcard)
       - rhyme compatibility
       - one example line
    The drafter's #1 weakness is treating cadences as named labels rather
    than concrete shapes; the stress + rhyme detail makes the bar shape land.
    """
    slugs = sorted({s.cadence_pattern for s in sections if s.cadence_pattern})
    if not slugs:
        return "(none)"
    placeholders = ",".join("?" * len(slugs))
    rows = db.execute(
        f"""
        SELECT slug, syllable_template, stress_template, rhyme_compatibility, example_lines
        FROM cadence_patterns WHERE slug IN ({placeholders})
        """,
        slugs,
    ).fetchall()
    if not rows:
        return "(none)"
    parts: list[str] = []
    for r in rows:
        rc = json.loads(r["rhyme_compatibility"]) if r["rhyme_compatibility"] else {}
        examples = json.loads(r["example_lines"]) if r["example_lines"] else []
        rc_end = rc.get("end") if isinstance(rc, dict) else None
        rc_internal = rc.get("internal") if isinstance(rc, dict) else None
        line = f"  {r['slug']}:"
        line += f" {r['syllable_template']} syll/line"
        if r["stress_template"]:
            line += f" | stress={r['stress_template']!r}"
        if rc_end:
            line += f" | end-rhyme={','.join(rc_end)}"
        if rc_internal:
            line += f" | internal-rhyme={rc_internal}"
        parts.append(line)
        if examples:
            parts.append(f"    e.g. \"{examples[0]}\"")
    return "\n".join(parts)


# ---------------- candidate scoring ----------------

def _score_targets(song: Song, target_ids: set[str]) -> tuple[int, int, int]:
    """Returns (passes, warns, fails) summed across rules of target sections.
    Higher passes is better; fewer warns/fails is better. Sortable as a tuple
    by negating warns and fails so a > b means b is better."""
    passes = warns = fails = 0
    for s in song.sections:
        if s.id not in target_ids:
            continue
        for rule in ("singability", "cadence", "phonetic_texture", "rhyme_cadence", "story_sentence"):
            v = getattr(s.validation, rule)
            if v == "pass":
                passes += 1
            elif v == "warn":
                warns += 1
            elif v == "fail":
                fails += 1
    return passes, warns, fails


def _score_key(score: tuple[int, int, int]) -> tuple[int, int, int]:
    """Sort key: maximize passes, minimize fails, minimize warns."""
    passes, warns, fails = score
    return (passes, -fails, -warns)


def _all_pass(song: Song, target_ids: set[str]) -> bool:
    # Cadence stress is excluded from the exit gate — it only WARNs (never FAILs)
    # and Claude cannot fix ARPAbet stress drift, so looping on it wastes iterations.
    GATED_RULES = ("singability", "phonetic_texture", "rhyme_cadence", "story_sentence")
    for s in song.sections:
        if s.id not in target_ids:
            continue
        for rule in GATED_RULES:
            v = getattr(s.validation, rule)
            if v == "fail":
                return False
            if v == "unrun":
                return False
    return True


# ---------------- burn-list scrub ----------------

def _scrub_burn(lines: list[str], burn: dict[str, list[str]]) -> list[str]:
    out: list[str] = []
    for line in lines:
        scrubbed = line
        for word, alts in burn.items():
            if not alts:
                continue
            replacement = alts[0]
            scrubbed = re.sub(rf"\b{re.escape(word)}\b", replacement, scrubbed, flags=re.IGNORECASE)
        out.append(scrubbed)
    return out


# ---------------- feedback formatter ----------------

def _build_feedback(song: Song, target_ids: set[str]) -> str:
    """Surface every fail/warn in a form Claude can act on.

    Cadence stress-pattern warnings are deliberately excluded: Claude has no access to
    CMUdict and cannot fix ARPAbet stress drift. Including them just causes Claude to
    pick awkward word choices chasing an unachievable metric. Syllable counts
    (singability) are included — Claude CAN count those.
    """
    parts: list[str] = []
    for s in song.sections:
        if s.id not in target_ids:
            continue
        section_issues = []
        for rule in ("singability", "phonetic_texture", "rhyme_cadence", "story_sentence"):
            v = getattr(s.validation, rule)
            if v in ("fail", "warn"):
                section_issues.append(f"{rule}: {v.upper()}")
        # Filter out cadence drift warnings — only include syllable-count issues from warnings
        actionable_warnings = [
            w for w in (s.validation.warnings or [])
            if "cadence drift" not in w
        ]
        if not section_issues and not actionable_warnings:
            continue
        parts.append(f"### Section {s.id} ({s.label}, cadence={s.cadence_pattern})")
        if section_issues:
            parts.append("  Verdicts: " + ", ".join(section_issues))
        if actionable_warnings:
            parts.append("  Specifics (these are the exact lines to fix):")
            for w in actionable_warnings[:8]:
                parts.append(f"    - {w}")
    return "\n".join(parts) or "(no specific issues — but Story Rule failed; the lyrics drift from the topic. Rewrite tighter to the topic.)"


def _build_prev_lyrics_block(song: Song, target_ids: set[str]) -> str:
    parts: list[str] = []
    for s in song.sections:
        if s.id not in target_ids:
            continue
        parts.append(f"### Section {s.id} ({s.label})")
        for i, line in enumerate(s.lyrics):
            parts.append(f"  {i}. {line or '(blank)'}")
    return "\n".join(parts)


# ---------------- section block ----------------

def _section_arc_hint(label: str, idx: int) -> str:
    """Map section label to a narrative role so Claude writes a story, not just rhymes."""
    ll = label.lower()
    if 'intro' in ll:
        return "establish mood and world — no plot yet, just atmosphere"
    if 'pre-chorus' in ll or 'pre-hook' in ll or 'prechorus' in ll:
        return "build tension — push emotionally toward the chorus drop"
    if 'chorus' in ll or 'hook' in ll or 'refrain' in ll:
        return "emotional peak — the repeating core idea; make it land every time"
    if 'bridge' in ll or 'breakdown' in ll or 'interlude' in ll:
        return "pivot — shift perspective, reveal a twist, or accelerate toward resolution"
    if 'outro' in ll or 'coda' in ll:
        return "close the arc — land the emotion and let it breathe"
    if 'verse' in ll:
        return "set the scene and advance the story" if idx <= 1 else "deepen or complicate — don't repeat verse 1, move the plot forward"
    return "develop the story"


def _section_block(sections: list[Section]) -> str:
    parts = []
    for idx, s in enumerate(sections):
        arc = _section_arc_hint(s.label, idx)
        parts.append(f"- id={s.id!r} label={s.label!r} cadence={s.cadence_pattern!r}")
        parts.append(f"  narrative role: {arc}")
        if s.rhyme_scheme and s.rhyme_scheme != "free":
            parts.append(f"  rhyme scheme: {s.rhyme_scheme} (enforce this end-rhyme pattern)")
    return "\n".join(parts)


# ---------------- the loop ----------------

def _apply_lyrics(song: Song, drafted_by_id: dict[str, Any], target_ids: set[str], burn: dict[str, list[str]]) -> None:
    for s in song.sections:
        if s.id not in target_ids:
            continue
        raw = drafted_by_id.get(s.id)
        if isinstance(raw, list):
            scrubbed = _scrub_burn([str(x) for x in raw], burn)
            s.lyrics = scrubbed


@router.post("/songs/{slug}/draft")
async def run_draft(
    slug: str,
    settings: Annotated[Settings, Depends(get_settings)],
    db: Annotated[sqlite3.Connection, Depends(get_db)],
    section: str | None = Query(None, description="Section id to draft. Omit to draft every empty section."),
    max_attempts: int = Query(MAX_ATTEMPTS, ge=1, le=8),
    fix: bool = Query(False, description="Start in correction mode — treat existing lyrics as the failed attempt 0 and feed their validation failures straight into the correction loop."),
) -> dict:
    if not path_for_slug(settings.songs_dir, slug).exists():
        raise HTTPException(404, f"song {slug!r} not found")
    song = read_song(settings.songs_dir, slug)

    if not song.sections:
        from songwriter.api.routes.draft_defaults import DEFAULT_SECTIONS
        song.sections = [
            Section(
                id=p["id"], label=p["label"], lock_state="draft",
                lyrics=[], cadence_pattern=p["cadence"],
            )
            for p in DEFAULT_SECTIONS
        ]

    if section is not None:
        targets = [s for s in song.sections if s.id == section]
        if not targets:
            raise HTTPException(404, f"section {section!r} not found in song")
    else:
        targets = [
            s for s in song.sections
            if s.lock_state != "locked" and (not s.lyrics or all(not l.strip() for l in s.lyrics))
        ]
        if not targets:
            raise HTTPException(409, "no empty unlocked sections to draft (use ?section=<id> to redraft one)")

    target_ids = {s.id for s in targets}

    # Pre-load context once
    pos, neg = _load_production(db, song.sub_genre)
    burn = _load_burn_dict(db)
    burn_words_str = ", ".join(sorted(burn.keys())) or "(none)"
    lens_block = _load_lens(db, song.songwriter_lens)
    cadence_compact = _load_cadence_compact(db, targets)
    initial_section_block = _section_block(targets)
    anchor_words_list, anchor_source, anchor_slug = resolve_vocab(
        db,
        genre=song.genre,
        emotion=song.intent.emotion_arc or "",
        topic=song.intent.topic or "",
        lens_slug=song.songwriter_lens or "",
    )
    anchor_words_str = ", ".join(anchor_words_list) if anchor_words_list else "(no anchors available — write to the topic directly)"
    pos_descriptors = ", ".join(pos[:6]) if pos else "(unspecified)"
    neg_descriptors = ", ".join(neg[:6]) if neg else "(unspecified)"

    best_song: Song | None = None
    best_score: tuple[int, int, int] | None = None
    best_attempt_idx = -1
    attempt_log: list[dict] = []

    # Fix mode: pre-seed the loop with the CURRENT lyrics so attempt 0 uses the
    # correction prompt (pointing at existing lyrics + their real failures) instead
    # of generating from scratch.
    if fix and all(s.lyrics and any(l.strip() for l in s.lyrics) for s in targets):
        pre = song.model_copy(deep=True)
        validate_song(pre, db, include_llm=False)
        best_song = pre
        best_score = _score_targets(pre, target_ids)
        attempt_log.append({"attempt": "pre-fix-validation", "score": list(best_score)})

    for attempt in range(max_attempts):
        if best_song is None:
            prompt = _INITIAL_PROMPT.format(
                topic=song.intent.topic or "(no topic specified)",
                event=song.intent.story.event,
                emotion=song.intent.story.emotion,
                resolution=song.intent.story.resolution,
                emotion_arc=song.intent.emotion_arc or "(unspecified)",
                genre=song.genre,
                sub_genre=song.sub_genre,
                lens_block=lens_block,
                anchor_source=f"{anchor_source}" + (f" ({anchor_slug})" if anchor_slug else ""),
                anchor_words=anchor_words_str,
                pos_descriptors=pos_descriptors,
                neg_descriptors=neg_descriptors,
                section_block=initial_section_block,
                cadence_compact=cadence_compact,
                burn_words=burn_words_str,
            )
        else:
            feedback = _build_feedback(best_song, target_ids)
            prev_block = _build_prev_lyrics_block(best_song, target_ids)
            prompt = _CORRECTION_PROMPT.format(
                topic=song.intent.topic or "(no topic specified)",
                event=song.intent.story.event,
                emotion=song.intent.story.emotion,
                resolution=song.intent.story.resolution,
                lens_block=lens_block,
                anchor_words=anchor_words_str,
                prev_lyrics_block=prev_block,
                feedback_block=feedback,
                burn_words=burn_words_str,
            )

        # Initial generation uses the quality model (sonnet); corrections use haiku.
        # Sonnet produces better lyrics; haiku is fast enough for targeted line fixes.
        llm_model = settings.fast_model if best_song is not None else settings.draft_model
        try:
            payload = ask_claude_json(prompt, model=llm_model)
        except LLMError as e:
            if attempt == 0:
                raise HTTPException(502, f"LLM call failed on first attempt: {e}")
            break  # keep best so far

        if not isinstance(payload, dict) or not isinstance(payload.get("sections"), list):
            if attempt == 0:
                raise HTTPException(502, "LLM returned malformed JSON (missing 'sections' array)")
            attempt_log.append({"attempt": attempt, "error": "malformed JSON; kept previous"})
            continue

        drafted_by_id: dict[str, Any] = {
            entry.get("id"): entry.get("lyrics")
            for entry in payload["sections"]
            if isinstance(entry, dict)
        }

        candidate = song.model_copy(deep=True)
        _apply_lyrics(candidate, drafted_by_id, target_ids, burn)
        # Deterministic-only on iterations to keep the loop fast.
        # The expensive LLM-judged Story Rule runs once on the final winner.
        validate_song(candidate, db, include_llm=False)

        score = _score_targets(candidate, target_ids)
        attempt_log.append({"attempt": attempt, "score": list(score)})

        if best_score is None or _score_key(score) > _score_key(best_score):
            best_score = score
            best_song = candidate
            best_attempt_idx = attempt

        if _all_pass(candidate, target_ids):
            break

    assert best_song is not None  # at least the first attempt always lands here

    # Final pass: LLM story check ONLY on target sections (not all N sections).
    # Cohesion still reads the whole song but only runs once here.
    try:
        validate_song(best_song, db, include_llm=True, llm_section_ids=target_ids)
        best_score = _score_targets(best_song, target_ids)
    except Exception as e:
        # Don't fail the whole draft if the LLM check times out; keep deterministic results
        attempt_log.append({"attempt": "final-llm-check", "error": str(e)})

    # Apply best to the source song
    for src, dst in zip(best_song.sections, song.sections):
        if dst.id in target_ids:
            dst.lyrics = src.lyrics
            dst.validation = src.validation
            dst.lock_state = "draft" if dst.lock_state != "locked" else "locked"

    # Copy the song-level cohesion check too (validate_song wrote it onto best_song)
    song.cohesion = best_song.cohesion

    song.last_modified_by = "api"
    song.modified = datetime.now(timezone.utc)

    try:
        from songwriter.api.main import app as _app
        w = getattr(_app.state, "watcher", None)
        if w is not None:
            w.note_self_write(slug)
    except Exception:
        pass

    write_song(settings.songs_dir, song)
    await ws_manager.broadcast(slug, {"type": "update", "song": song.model_dump(mode="json")})

    return {
        "song": song.model_dump(mode="json"),
        "draft": {
            "best_attempt": best_attempt_idx + 1,
            "attempts_used": len(attempt_log),
            "max_attempts": max_attempts,
            "best_score": {
                "passes": best_score[0] if best_score else 0,
                "warns": best_score[1] if best_score else 0,
                "fails": best_score[2] if best_score else 0,
            },
            "all_pass": _all_pass(song, target_ids),
            "anchor_words": {
                "source": anchor_source,
                "bank_slug": anchor_slug,
                "count": len(anchor_words_list),
            },
            "log": attempt_log,
        },
    }
